# Regression Testing Strategy

## Change Impact

Version B changes two behaviors:

1. `IsInTheSet` now returns `true` when the searched value exists.
2. `AddAValue` now prevents writes past capacity and throws `IndexOutOfBoundsException` with a stable message.

Both changes affect the core set invariant: uniqueness and safe insertion.

## Team Selection

The team choice is to rerun the full suite after the fix because:

- the codebase is tiny;
- both modified methods are directly or indirectly used by most scenarios;
- the cost of rerunning all tests is negligible;
- a full rerun gives stronger confidence than a narrow subset.

## LLM-Assisted Selection

The LLM-selected minimal subset to re-execute is:

- `testAddAValue_DuplicateValue`
- `testIsInTheSet_EmptySet`
- `testIsInTheSet_ValuePresent`
- `testMultipleAdds`
- `testAddMoreThanCapacity`

This subset focuses on the changed decision points and the new exception path.

## Justification

- Duplicate handling depends on `IsInTheSet`, so the duplicate-insert test must be rerun.
- Positive lookup validates the repaired search logic.
- Multiple adds exercise several loop iterations and state updates.
- Capacity overflow validates the new guard and message.
- Empty lookup confirms the method still returns `false` when the loop does not execute.

Because the suite is small, the recommended practical strategy remains rerunning all tests after the fix.