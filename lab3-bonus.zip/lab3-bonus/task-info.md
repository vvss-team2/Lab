# Task Info

## Team Members

- TODO: add team member 1
- TODO: add team member 2
- TODO: add team member 3
- TODO: add team member 4
- TODO: add team member 5

## Completed Technical Work

- Version A preserved with the original bugs.
- Version A JUnit suite added.
- Version B created with fixed lookup and capacity handling.
- Regression strategy and LLM prompt log added.

## Remaining Manual Submission Items

- Replace the placeholder team member names with the real names.
- Export the markdown files to PDF or DOCX only if your course submission requires that format.
- Submit the separate consent form and questionnaire outside this repository if needed.
