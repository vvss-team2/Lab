# Test Cases

## Scope

The suite targets constructor behavior, insertion rules, membership lookup, duplicate handling, and capacity boundaries.

## Designed Tests

| Test | Technique | Purpose | Expected in Version A | Expected in Version B |
| --- | --- | --- | --- | --- |
| `testConstructor` | Black-box | Verify the set starts empty with the requested capacity. | Pass | Pass |
| `testAddAValue_NewValue` | Black-box | Check that inserting a fresh value succeeds and updates state. | Pass | Pass |
| `testAddAValue_DuplicateValue` | Black-box | Check that duplicate insertion is rejected. | Fail | Pass |
| `testIsInTheSet_EmptySet` | Black-box | Check lookup in an empty set. | Pass | Pass |
| `testIsInTheSet_ValuePresent` | Black-box | Check lookup for an existing value. | Fail | Pass |
| `testIsInTheSet_ValueNotPresent` | Black-box | Check lookup for a missing value. | Pass | Pass |
| `testMultipleAdds` | White-box | Exercise repeated state updates and several loop iterations. | Fail | Pass |
| `testAddMoreThanCapacity` | Black-box boundary | Check behavior at `capacity + 1`. | Fail | Pass |

## Technique Summary

- Black-box reasoning covers the externally visible rules: empty initialization, successful insertion, duplicate rejection, lookup results, and overflow handling.
- White-box reasoning was used on `IsInTheSet` and `AddAValue` because the control flow has an obvious risky loop-and-branch interaction. The suite covers zero loop iterations, one or more loop iterations, and the exceptional path when the backing array is full.