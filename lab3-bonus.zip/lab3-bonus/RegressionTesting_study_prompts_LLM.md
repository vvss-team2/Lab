# LLM Prompts and Responses

## Task 1 Prompt

Given the following Java `Set` implementation, design a JUnit 4 test suite that uses both black-box and white-box reasoning to expose likely bugs. Cover constructor behavior, adding values, duplicate handling, membership lookup, and capacity boundaries.

## Task 1 LLM Response Summary

- Test constructor initialization.
- Test adding a fresh value.
- Test duplicate rejection.
- Test membership lookup for empty, present, and absent values.
- Test multiple insertions to cover several loop iterations.
- Test insertion past capacity and expect `IndexOutOfBoundsException("Set capacity exceeded")`.
- Expect Version A failures in duplicate handling, positive membership checks, and capacity overflow handling.

## Task 4 Prompt

Given Version A above and a Version B where `IsInTheSet` is fixed and `AddAValue` checks capacity, select the regression tests that should be re-executed and justify the choice.

## Task 4 LLM Response Summary

- Mandatory regression subset: duplicate add, empty lookup, present lookup, multiple adds, and capacity overflow.
- Because the suite is small and the changed methods are core behaviors, rerunning the full suite is the safer practical choice.
