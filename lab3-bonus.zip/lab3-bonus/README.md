# Lab 3 Bonus - Problem Set Regression Testing

This folder packages the bonus exercise as two separate Maven modules so Version A and Version B can be executed independently.

- `version-a` keeps the original buggy `Set` implementation and the designed JUnit suite.
- `version-b` contains the bug-fixed implementation and the same functional tests.

The top-level `Set.java` and `RunSet.java` files are preserved as the raw handout copy. The runnable deliverables live inside the module folders.

## Run

```bash
cd lab3-bonus
mvn -pl version-a test
mvn -pl version-b test
```

`version-a` is expected to fail part of the suite because it preserves the original bugs. `version-b` should pass the full suite.